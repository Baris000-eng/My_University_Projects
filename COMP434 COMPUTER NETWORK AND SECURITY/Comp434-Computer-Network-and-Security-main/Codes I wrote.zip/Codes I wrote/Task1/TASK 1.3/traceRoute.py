#!/usr/bin/env python3

from scapy.all import *

a = IP() #creating an ip object
a.dst="10.9.0.5" #setting the destination ip address to "10.9.0.5"


print("Destination = "+str(a.dst))
print("Source = "+str(a.src))


for w in range(1,10):
    a.ttl=w
    b=ICMP()
    a=sr1(a/b)
    if a.src=="10.9.0.5":
        print("Desired destination is reached !")
        break
        
        

   
