#include <linux/if_packet.h>
#include <net/ethernet.h>
#include <pcap.h>
#include <stdio.h>
#include <math.h>
#include <ctype.h>
#include <time.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <string.h>
#include <stdlib.h>

struct ipheader {
 unsigned char iph_ihl:4;
 unsigned char iph_ver:4;
 unsigned char iph_tos;
 unsigned short int iph_len;
 unsigned short int iph_ident;
 unsigned short int iph_flag:3;
 unsigned short int iph_offset:13;
 unsigned char iph_ttl;
 unsigned char iph_protocol;
 unsigned short int iph_chksum;
 struct in_addr iph_sourceip;
 struct in_addr iph_destip;
};


struct icmpheader {
 unsigned char icmp_type;
 unsigned char icmp_code;
 unsigned short int icmp_chksum;
 unsigned short int icmp_id;
 unsigned short int icmp_seq;
};


struct ethheader {
 unsigned short ether_dhost[6];
 unsigned char ether_shost[6];
 unsigned short ether_type;
};


void transfer_raw_ip_packets_with_sockets(struct ipheader* ip_struct_val){
    printf("\n\n Start of the transfer of raw ip packets with sockets !!! \n\n ");
    int enable_variable = 1;
    int socket_var = socket(AF_INET, SOCK_RAW, IPPROTO_RAW);
    if(socket_var <= -1){
        printf("\n\n An error happened while creating a raw socket !!! \n\n\n");
        exit(EXIT_FAILURE);
    }
struct sockaddr_in destination_information;
int size_en=sizeof(enable_variable);
setsockopt(socket_var, IPPROTO_IP, IP_HDRINCL,
&enable_variable, size_en);
destination_information.sin_family = AF_INET;
destination_information.sin_addr = ip_struct_val->iph_destip;
int size_dest = sizeof(destination_information);
if(sendto(socket_var, ip_struct_val, ntohs(ip_struct_val->iph_len), 0,
          (struct sockaddr *)&destination_information, size_dest)<=-1){
    printf("\n\n An error happened while sending the raw packets and performing the spoofing process !!! \n\n\n ");
    exit(EXIT_FAILURE);
}
 printf("\n\n End of the transfer of raw ip packets with sockets !!! \n\n ");
 close(socket_var);
}

void obtain_packet_inf(unsigned char *args, const struct pcap_pkthdr *hd,
 const unsigned char *pck) {
 struct ethheader* eth_struct_val = (struct ethheader *)pck;
 printf("\n\n Start of the process of obtaining the packet information !!! \n\n\n ");
 if (ntohs(eth_struct_val->ether_type) == 0x0800) { // Here, 0x0800 represents the type of the IP
 struct ipheader * ip_struct_data = (struct ipheader *)
 (pck + sizeof(struct ethheader));
     unsigned char head_len = ip_struct_data->iph_ihl;
     int s_ip_val = 4*head_len; //byte order conversion process
 printf(" The current source ip address is the following: %s\n", inet_ntoa(ip_struct_data->iph_sourceip));
 printf(" The current destination ip address is the following: %s\n", inet_ntoa(ip_struct_data->iph_destip));

unsigned char protocol_val= ip_struct_data->iph_protocol;
     if(protocol_val==IPPROTO_UDP){
         printf("\n\n This Protocol Type is UDP Protocol !!! \n\n\n ");
     } else if(protocol_val==IPPROTO_ICMP){
         printf("\n\n\n This protocol type is ICMP protocol \n\n\n");
         struct icmpheader* icmpDt=(struct icmpheader*)((unsigned char *)pck + sizeof(struct ethheader)+s_ip_val);
         int capacity=2000;
         char buff_str[capacity];
         int sum_of_the_sizes = sizeof(struct ethheader)+sizeof(struct ipheader)+sizeof(struct icmpheader);
         int length_val_of_dt = hd->len-sum_of_the_sizes;
         char* dt_string= pck+sum_of_the_sizes;
         int s = sizeof(struct icmpheader)+sizeof(struct ipheader);
         memcpy(buff_str+s,dt_string, length_val_of_dt);

         struct ipheader *ip_head_str = (struct ipheader *) buff_str;
         ip_head_str->iph_ver = 4;
         ip_head_str->iph_ttl = 50;
         ip_head_str->iph_sourceip = ip_struct_data->iph_destip;
         ip_head_str->iph_destip = ip_struct_data->iph_sourceip;
         ip_head_str->iph_protocol = IPPROTO_ICMP;
         int size_sum_val = sizeof(struct icmpheader) + length_val_of_dt+ sizeof(struct ipheader);
         ip_head_str->iph_len = htons(size_sum_val);
         int wordNum=ip_struct_data->iph_ihl;
         int ip_size_val=wordNum*4;
         struct icmpheader *icmp = (struct icmpheader *)
         (buff_str + ip_size_val);
         icmp->icmp_type = 0;
         transfer_raw_ip_packets_with_sockets (ip_struct_data);
         printf("\n\n End of the process of obtaining the packet information !!! \n\n\n ");
     } else if(protocol_val==IPPROTO_TCP){
         printf("\n\n\n This protocol type is TCP Protocol !!! \n\n\n");
     } else {
         if(protocol_val==' '){
             printf("\n\n Invalid or Wrong Protocol Type !!!! \n\n\n");
         } else {
             printf("\n\n The Protocol Type is different from the TCP, UDP, and ICMP.");
         }

     }

 }
    }


int main() {
    struct bpf_program berkeley_packet_filter;
    pcap_t *handle_variable;
    char error_buffer[PCAP_ERRBUF_SIZE];
    bpf_u_int32 net_variable;
    char filter_expression_str[] = "proto ICMP";
    printf("\n\n Pcap library calls start here ... \n\n");
    char *i_face_str="br-90b7eb23ec7c";
    int ttl_val=1000;
    int prom_mode=1;
    handle_variable = pcap_open_live(i_face_str, BUFSIZ, prom_mode, ttl_val, error_buffer);
    if(handle_variable==NULL){
        printf("\n\n An error happened while opening a live session \n\n ");
        exit(EXIT_FAILURE);
    }
    if(pcap_compile(handle_variable, &berkeley_packet_filter, filter_expression_str, 0, net_variable) < 0){
        printf("\n\n An error happened while compiling the packet filter !! \n\n");
        exit(EXIT_FAILURE);
    }
    if(pcap_setfilter(handle_variable, &berkeley_packet_filter)<0){
        printf("\n\n An error happened while setting the filter !! \n\n ");
        exit(EXIT_FAILURE);
    }
    int inf_loop = -1;
    pcap_loop(handle_variable, inf_loop, obtain_packet_inf, NULL);
    pcap_close(handle_variable);
    printf("\n\n Pcap library calls end here ... \n\n");
    return 0;

}
