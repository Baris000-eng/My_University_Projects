#!/usr/bin/env python3

from scapy.all import *

a = IP() #creating an ip object
a.dst='10.9.0.5' #setting the destination ip address to "10.9.0.5"
b = ICMP() #creating an icmp object
P = a/b
send(p)
ls(a)
   
