#include <stdio.h>
#include <pcap/pcap.h>
#include <netinet/in.h>
#include<string.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <netinet/tcp.h>

struct ethheader {
	    unsigned char ether_dhost[6]; 
	    unsigned char ether_shost[6]; 
	    unsigned short ether_type;
};
	
struct ipheader { 
	    unsigned char iph_ihl:4;        
	    unsigned char iph_ver:4;
	    unsigned char iph_tos;
	    unsigned short int iph_len;
	    unsigned short int iph_ident;
	    unsigned short int iph_flag:3;
	    unsigned short int iph_offset:13;
	    unsigned char iph_ttl;
	    unsigned char iph_protocol;
	    unsigned short int iph_chksum;
	    struct in_addr iph_sourceip;
	    struct in_addr iph_destip;
}; 
    
	void obtain_packet_information(u_char *args, const struct pcap_pkthdr *header, const u_char *packet) {
	    struct ipheader *ip_struct_val = (struct ipheader*) (packet + sizeof(struct ethheader)); //creating an ipheader instance
	    int size_value_ip = ((ip_struct_val->iph_ihl))* 4;
	    struct tcphdr *tcp_str = (struct tcphdr *) (packet + sizeof(struct ethheader) + size_value_ip); //creating a tcpheader instance
	    int size_value_tcp = (tcp_str->th_off) * 4;
	    unsigned char *string_val = (unsigned char *) (packet + sizeof(struct ethheader) + size_value_ip + size_value_tcp);
        int sum_tcp_and_ip_sizes = size_value_ip + size_value_tcp;
	    int size_data_val = ntohs(ip_struct_val->iph_len) - sum_tcp_and_ip_sizes;
	    int y = 0;
	        for (y = 0; y < size_data_val; y++) {
	            printf("%c", string_val[y]); // displaying the default root password
	        }
	    }
	
	int main() {
	    pcap_t *handle_string_value;
	    char errbuf[PCAP_ERRBUF_SIZE];
	    struct bpf_program fp;
	    char filter_exp_tcp[] = "tcp port 23"; //specifying the filter type
	    bpf_u_int32 net = 0;
	    bpf_u_int32 mask = 0;
	
	    char *interface_string="br-90b7eb23ec7c"; //specifying the interface
	    int promisciousModeOn=1;
	    int infinite_loop=-1;
	    handle_string_value = pcap_open_live(interface_string, BUFSIZ, promisciousModeOn, 1000, errbuf); //opening the session
	    pcap_lookupnet(interface_string, &net, &mask, errbuf);
	    pcap_compile(handle_string_value, &fp, filter_exp_tcp, 1, net);
	    pcap_setfilter(handle_string_value, &fp);
	    pcap_loop(handle_string_value, infinite_loop, obtain_packet_information, NULL);
	    pcap_close(handle_string_value); //closing the packet capturing session
	    return 0;
	}
