#!/usr/bin/env python3

from scapy.all import *

def packet_transmission(pkt):

    print("Initial Point")

    if pkt is None:
        print("No packet is found !!!")

        if (pkt[ICMP].type == 8):
            pkt.show()
        print("ICMP Request comes!! The Source is "+str(pkt[1].src)+". The Destination is "+str(pkt[1].dst)+"")
        print("ICMP Reply comes!! The Source is "+str(pkt[1].dst)+". The Destination is "+str(pkt[1].src)+"")
        z = IP(src=pkt[1].dst, dst=pkt[1].src)
        h = ICMP()
        h.type=0
        x = z/h
        x.show()
        send(x)
   
    print("End Point")
       

pkt = sniff(iface = "br-90b7eb23ec7c",filter = 'icmp', prn = packet_transmission)
   
