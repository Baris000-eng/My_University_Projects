#!/usr/bin/env python3

from scapy.all import *

def print_pkt(pkt):
    pkt.show()


my_inf=['br-90b7eb23ec7c']
pkt = sniff(iface=my_inf,filter='net 128.230.0.0/16',prn=print_pkt)

  
