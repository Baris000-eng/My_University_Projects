from scapy.all import *

b = IP()
b.show()

  
