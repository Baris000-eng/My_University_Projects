#!/usr/bin/env python3

from scapy.all import *

def print_pkt(pkt):
    pkt.show()
    print("The destination port number is "+str(pkt[TCP].dport)+"")


pkt = sniff(iface='br-90b7eb23ec7c',filter='tcp dst port 23 and src host 10.9.0.6',prn=print_pkt)
#I have used tcp dst port 23 filter in order to filter the destination ports to tcp ports having the number
#23. I have used src host 10.9.0.6 in order to filter the source hosts to 10.9.0.6.



  
