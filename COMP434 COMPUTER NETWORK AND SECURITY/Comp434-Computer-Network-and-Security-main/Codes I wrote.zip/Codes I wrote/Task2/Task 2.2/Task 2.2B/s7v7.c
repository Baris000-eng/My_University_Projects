#include <stdlib.h>
#include <time.h>
#include <netinet/ip_icmp.h> //for built in icmp struct usage
#include <arpa/inet.h>
#include <netinet/in.h>
#include <unistd.h>
#include <string.h>
#include <netinet/ip.h> //for built in ip struct usage
#include <sys/socket.h> //for socket creation methods
#include <stdio.h>

unsigned short evaluate_checksum_value(unsigned short *buf, int l);

int main() {
    int flag_number = 0;
    int ttl_val = 90;
    int capacity_value = 40000;
    char dt_str[capacity_value] = "Hi!\n"; //message to be transmitted
    struct ip iphdr_struct_value;
    iphdr_struct_value.ip_v = 4; //version num
    iphdr_struct_value.ip_hl = 5; //ip header length
    iphdr_struct_value.ip_tos = 0;
    int l = strlen(dt_str);
    int d_l = l + 1;
    struct icmp icmphdr_struct_value;
    iphdr_struct_value.ip_len = htons(28 + d_l);
    iphdr_struct_value.ip_id = 0;
    fl_n=4;
    int ip_flags[fl_n] = {0, 0, 0, 0}; //initialization of the ip flags
    iphdr_struct_value.ip_ttl = ttl_val;
    iphdr_struct_value.ip_p = IPPROTO_ICMP; //specifying the protocol
    
    
    
    char *source_ip_addr = "10.9.0.6";
    char *destination_ip_addr = "8.8.8.8";
    
    
    
    if ((inet_pton(AF_INET, source_ip_addr, &(iphdr_struct_value.ip_src))) <= 0 ||
        (inet_pton(AF_INET, destination_ip_addr, &(iphdr_struct_value.ip_dst)))<= 0){
        printf("\n Error happened about the destination ip address or the source ip adddress !!!\n\n\n"); //error cases for destination ip address and source ip address
        return 2;
    } else {
        printf("\n\n Successful string to binary conversion for the source and the destination ip addresses !!! \n\n\n "); //successful ip address conversion case
    }
    
    
    icmphdr_struct_value.icmp_seq = 0;
    iphdr_struct_value.ip_sum = evaluate_checksum_value((unsigned short *) &iphdr_struct_value, 20);
    icmphdr_struct_value.icmp_type = 8;
    icmphdr_struct_value.icmp_code = 0;
    int capacity_int_val = 40000;
    
    
    char pc[capacity_int_val];
    memcpy(pc, &iphdr_struct_value, 20); // memory copy for the ipheader instance
    memcpy((pc + 20), &icmphdr_struct_value, 8);
    //memory copy for the icmpheader instance
    memcpy(pc + 28, dt_str, d_l);
    icmphdr_struct_value.icmp_cksum = evaluate_checksum_value((unsigned short *) (pc + 20), 8 + d_l);
    
    
    
    
    //evaluating the checksum value for the icmpheader instance and assigning the resulting value to the icmp_cksum attribute of the icmphdr instance
    memcpy(pc + 20, &icmphdr_struct_value, 8);
    printf("\n Start spoofing with raw sockets !!!\n\n\n"); //start to spoof message
    struct sockaddr_in destination_trck;
    int s = sizeof(struct sockaddr_in);
    memset(&destination_trck, 0, s);
    destination_trck.sin_family = AF_INET; //a data structure definition which is necessary for spoofing raw packets using sockets
    destination_trck.sin_addr.s_addr = iphdr_struct_value.ip_dst.s_addr;
    int socket_var = socket(AF_INET, SOCK_RAW, IPPROTO_RAW); //calling socket function for creating a raw socket
    if(socket_var < 0) { //Definition of the error case for socket creation
        printf("\n Error happened while creating a socket !!! \n\n\n");
        return 2;
    } else {
        printf("\n\n\n Successful socket creation !!! \n\n\n"); // no error case in socket creation
    }
    int size = sizeof(destination_trck);
    if (sendto(socket_var, pc, 28 + d_l, 0,
               (struct sockaddr *) &destination_trck, size) < 0) {
        //definition of the error case while sending the raw packets and performing the spoofing
        printf("\n Error happened while spoofing !!! \n\n\n");
        return 2;
    } else { //success case
        char * destination_ip_address = "8.8.8.8"; //destination ip
        char * source_ip_address = "10.9.0.6"; //source ip
        printf("\nICMP echo request packets are successfully spoofed !!!\n\n\n"); // a success message indicating the no error case for spoofing
        printf("\n A raw packet is successfully sent from the source ip address %s to the destination ip address %s \n\n\n", source_ip_address,destination_ip_address);
           //displaying an informative message which is related to the source ip address and the destination ip address of the raw packets that are sent.
    }
    
    
    
    close(socket_var); //closing the session
    printf("\n End of the spoofing with raw sockets !!!\n\n\n"); // the end of spoofing
    return 0;
    
    
    
    
}
unsigned short evaluate_checksum_value(unsigned short *buf, int l) {
    printf("\n Start of the checksum calculation !!!\n\n\n");
    int my_var = l; //necessary variable definitions
    int summation_var = 0;
    unsigned short *string_var = buf;
    unsigned short res_var= 0;
    while (my_var - 1 > 0) {
        summation_var = summation_var + (*string_var++);
        my_var = my_var-2;
    }
    if (my_var == 1) {
        *((unsigned char *) &res_var) = *((unsigned char *) string_var);
        summation_var = summation_var + res_var;
    }
    int lower_part = summation_var>>16; //lower bit part
    int upper_part = summation_var & 0xffff; //upper bit part
    summation_var = lower_part+upper_part;
    summation_var = summation_var + lower_part; //addition process of the carry value part.
    printf("\n End of the checksum calculation !!!\n\n\n");
    return (~summation_var);
}
	

