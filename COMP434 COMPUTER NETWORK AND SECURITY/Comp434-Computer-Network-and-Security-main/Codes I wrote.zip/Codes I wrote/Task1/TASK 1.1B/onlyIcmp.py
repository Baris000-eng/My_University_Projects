#!/usr/bin/env python3

from scapy.all import *

def print_pkt(pkt):
    pkt.show()


pkt = sniff(iface='br-90b7eb23ec7c',filter='icmp',prn=print_pkt)
#I have used icmp string inside the filter in order to capture only ICMP packets.



  
